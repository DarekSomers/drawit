package drawit.shapegroups2;

import drawit.IntPoint;

public class Extent {
	
	private int left;
	private int top;
	private int width;
	private int height;
	
	public int getLeft() {
		return left;
	}
	
	public int getTop() {
		return top;
	}

	public int getWidth() {
		return width;
	}

	public int getHeight() {
		return height;
	}
	
	public int getRight() {
		return getLeft()+getWidth();
	}

	public int getBottom() {
		return getTop() + getHeight();
	}
	
	public IntPoint getTopLeft() {
		IntPoint topLeft = new IntPoint(getLeft(), getTop());
		return topLeft;
	}
	
	public IntPoint getBottomRight() {
		IntPoint bottomRight = new IntPoint(getRight(), getBottom());
		return bottomRight;
	} 

	
	public boolean contains(IntPoint point) {
		if (point.getX() >= getLeft() && point.getX() <= getRight() && point.getY() <= getBottom() && point.getY() >= getTop())
			return true;
		else
			return false;
		
	}

	
	public static Extent ofLeftTopWidthHeight(int left, int top, int width, int height) {
		Extent ex = new Extent();
		ex.left = left;
		ex.top = top;
		ex.width = width;
		ex.height = height;
		return ex;
	}
	
	
	public static Extent ofLeftTopRightBottom(int left, int top, int right, int bottom) {
		Extent ex = new Extent();
		ex.left = left;
		ex.top = top;
		ex.width = right - left;
		ex.height = bottom - top;
		return ex;
	}
	
	
	public Extent withLeft(int newLeft) {
		Extent ex = new Extent();
		ex.left = newLeft;
		ex.top = getTop();
		ex.width = getRight() - newLeft;
		ex.height = getHeight();
		return ex;
	}
	
	
	public Extent withTop(int newTop) {
		Extent ex = new Extent();
		ex.left = getLeft();
		ex.top = newTop;
		ex.width = getWidth();
		ex.height = getBottom() - newTop;
		return ex;
	}
	
	
	public Extent withRight(int newRight) {
		Extent ex = new Extent();
		ex.left = getLeft();
		ex.top = getTop();
		ex.width = newRight - getLeft();
		ex.height = getHeight();
		return ex;
	}
	
	
	public Extent withBottom(int newBottom) {
		Extent ex = new Extent();
		ex.left = getLeft();
		ex.top = getTop();
		ex.width = getWidth();
		ex.height = newBottom - getTop();
		return ex;
	}
	
	
	public Extent withWidth(int newWidth) {
		Extent ex = new Extent();
		ex.left = getLeft();
		ex.top = getTop();
		ex.width = newWidth;
		ex.height = getHeight();
		return ex;
	}
	
	
	public Extent withHeigth(int newHeight) {
		Extent ex = new Extent();
		ex.left = getLeft();
		ex.top = getTop();
		ex.width = getWidth();
		ex.height = newHeight;
		return ex;
	}
	
}
