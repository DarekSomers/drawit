package drawit.tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class Controlpoints2Test {

	@Test
	void test() {
		//Methodes zijn getest in RoundedPolygonShapeTest en ShapeGroupShapeTest
		System.out.println("Methodes zijn getest in RoundedPolygonShapeTest en ShapeGroupShapeTest");
	}

}
