package drawit.shapegroups2;

import java.util.ArrayList;
import java.util.List;
import drawit.DoublePoint;
import drawit.IntPoint;
import drawit.IntVector;
import drawit.RoundedPolygon;


/**
 * @invar this Shapegroup does not have the same ShapeGroup as a child twice
 * 		//|  LogicalList.distinct(getSubgroups())
 * @invar this ShapeGroup's children have this ShapeGroup as their parent
 * 		|  getSubgroups().stream().allMatch(child -> child.getParentGroup() == this)
 * @invar this Shapegroup is a root ShapeGroup or else it is among parent's children
 * 		|  getParentGroup() == null || getParentGroup().getSubgroups().contains(this)
 * @invar this Shapegroup does not have itself as an ancestor
 * 		|  !getSubgroups().contains(this)
 */
public class ShapeGroup {
	/**
	 * Contains the leaf RoundedPolygon object
	 * @invar leaf is null when nonLeaf is not null and vice versa
	 * 		| (nonLeaf == null && leaf != null) || (leaf == null && nonLeaf != null)
	 */
	private RoundedPolygon leaf;
	/**
	 * Contains the nonLeaf object
	 * @invar nonLeaf is null when leaf is not null and vice versa
	 * 		| (nonLeaf == null && leaf != null) || (leaf == null && nonLeaf != null)
	 */
	private ShapeGroup[] nonLeaf;
	/**
	 * Contains the original extent when initializing the ShapeGroup
	 * @invar The extent cannot be null
	 * 		| !(getOriginalExtent() == null)
	 */
	private Extent ex;
	/**
	 * Contains the new extent when initializing the ShapeGroup and setting new extents
	 * @invar The new extent cannot be null
	 * 		| !(getExtent() == null)
	 */
	private Extent newEx;
	/**
	 * Contains the last set extent before setting a new extent
	 * @invar The extent cannot be null
	 * 		| !(prevEx == null)
	 */
	private Extent prevEx;
	/**
	 * Contains the parent ShapeGroup of this ShapeGroup
	 */
	private ShapeGroup parent;
	/**
	 * Contains the first ShapeGroup contained in parent's subgroups list or null when it's empty
	 */
	protected ShapeGroup first; //Only for non-leaves/parents
	/**
	 * Contains the last ShapeGroup contained in parent's subgroups list or null when it's empty
	 */
	private ShapeGroup last; //Only for non-leaves/parents
	/**
	 * Contains the next/following ShapeGroup contained in parent's subgroups list or null when there is none
	 */
	private ShapeGroup next; //Only for children
	/**
	 * Contains the previous ShapeGroup contained in parent's subgroups list or null when there is none
	 */
	private ShapeGroup previous; //Only for children
	
	
	
	/**
	 * Shows the change of the left value of the extent when the right value is updated
	 */
	private double changeXl = 0;
	/**
	 * Shows the change of the right value of the extent when the left value is updated
	 */
	private double changeXr = 0;
	/**
	 * Shows the change of the top value of the extent when the bottom value is updated
	 */
	private double changeYt = 0;
	/**
	 * Shows the change of the bottom value of the extent when the top value is updated
	 */
	private double changeYb = 0;


	/**
	 * Initializes the ShapeGroup with the extent created from the vertices of the given shape/RoundedPolygon
	 */
	public ShapeGroup(RoundedPolygon shape) {
		leaf = shape;
		int minX = leaf.getVertices()[0].getX();
		int maxX = leaf.getVertices()[0].getX();
		int minY = leaf.getVertices()[0].getY();
		int maxY = leaf.getVertices()[0].getY();
		
		for (IntPoint vertix: leaf.getVertices()) {
			if (vertix.getX() < minX)
				minX = vertix.getX();
			if (vertix.getX() > maxX)
				maxX = vertix.getX();
			if (vertix.getY() < minY)
				minY = vertix.getY();
			if (vertix.getY() > maxY)
				maxY = vertix.getY();
		}
		setExtent(Extent.ofLeftTopRightBottom(minX, minY, maxX, maxY));
	}
	
	/**
	 * Initializes the ShapeGroup with the extent created from the values of the given extents contained in the ShapeGroup array 
	 * And also assigns the children and parent objects
	 */
	public ShapeGroup(ShapeGroup[] subgroups) {
		nonLeaf = subgroups;
		ShapeGroup[] subgroup = nonLeaf;
		while (subgroup[0].leaf == null) {
			subgroup = subgroup[0].nonLeaf;
		}
		int minX = subgroup[0].getExtent().getLeft();
		int maxX = subgroup[0].getExtent().getRight();
		int minY = subgroup[0].getExtent().getBottom();
		int maxY = subgroup[0].getExtent().getTop();
		
		//children = new ShapeGroup[getSubgroupCount()];
		first = getSubgroup(0);
		last = getSubgroup(getSubgroupCount()-1);
		
		for (int i = 0; i < getSubgroupCount(); i++) {
			//children[i] = getSubgroup(i);
			getSubgroup(i).parent = this;
			if (i > 0)
				getSubgroup(i).previous = getSubgroup(i-1);
			if (i < getSubgroupCount()-1)
				getSubgroup(i).next = getSubgroup(i+1);
			
			if (getSubgroup(i).getExtent().getLeft() < minX)
				minX = getSubgroup(i).getExtent().getLeft();
			if (getSubgroup(i).getExtent().getRight() > maxX)
				maxX = getSubgroup(i).getExtent().getRight();
			if (getSubgroup(i).getExtent().getTop() < minY)
				minY = getSubgroup(i).getExtent().getTop();
			if (getSubgroup(i).getExtent().getBottom() > maxY)
				maxY = getSubgroup(i).getExtent().getBottom();
		}
		setExtent(Extent.ofLeftTopRightBottom(minX, minY, maxX, maxY));
	}
	
	/**
	 * Returns the extent of the ShapeGroup expressed in its outer coordinate system
	 * @return newEx
	 */
	public Extent getExtent() {
		return newEx;
	}
	
	/**
	 * Returns the extent of the ShapeGroup expressed in its inner coordinate system
	 * @return ex
	 */
	public Extent getOriginalExtent() {
		return ex;
	}
	
	/**
	 * Returns the ShapeGroup that directly contains this ShapeGroup or null if no shapeGroup directly contains this ShapeGroup
	 * @return parent
	 * @post if parent is null, the given ShapeGroup is a root ShapeGroup
	 * 		| result == null || result != null
	 */
	public ShapeGroup getParentGroup() {
		if (parent == null)
			return null;
		else
			return parent;
	}
	
	/**
	 * Returns the shape directly contained by this ShapeGroup or null if this is a nonLeaf ShapeGroup
	 * @return leaf
	 */
	public RoundedPolygon getShape() {
		if (nonLeaf != null)
			return null;
		else
			return leaf;
	}
	
	
	/**
	 * Returns the list of subgroups of this ShapeGroup or null if this is a leaf ShapeGroup
	 * @return list || null
	 * @post contains the child ShapeGroups from the nonLeaf array
	 * getSubgroups().stream().allMatch(child -> child == 
	 * 		
	 */
	public java.util.List<ShapeGroup> getSubgroups(){
		if (leaf != null)
			return null;
		else {
			List<ShapeGroup> list = new ArrayList<ShapeGroup>();
			ShapeGroup shape = first;
			while (shape != null) {
				list.add(shape);
				shape = shape.next;
			}
			return list;
		}
			
			 
	}
	
	
	/**
	 * Returns the number of subgroups of this nonLeaf ShapeGroup
	 * @return nonLeaf.length
	 */
	public int getSubgroupCount() {
		return nonLeaf.length;
	}
	
	
	/**
	 * Returns the subgroup at the given 0-based index in this nonLeaf ShapeGroup's list of subgroups
	 * @return return nonLeaf[index]
	 * 
	 */
	public ShapeGroup getSubgroup(int index) {
		if (index >= nonLeaf.length)
			throw new IllegalArgumentException("Index out of bounds");
		else {
			ShapeGroup shape;
			if (getExtent() != null) {
				shape = first;
				for (int i = 1; i <= index; i++)
					shape = shape.next;
			}
			else {
				shape = nonLeaf[index];
					
			}
			return shape;
		}
	}
	
	
	
	/**
	 * Returns the coordinates in this ShapeGroups innercoordinate's system of the point whose coordinates in the globalcoordinate's system are the given coordinates
	 * @return innerCoordinates
	 * @post Undoes all of the scalings of this ShapeGroup's extent compared to its original extent and translations of this ShapeGroup and its ancestors extent compared to its original extent
	 */
	public IntPoint toInnerCoordinates(IntPoint globalCoordinates) {
		
		if (getSubgroups() != null) {
			for (ShapeGroup child: getSubgroups()) {
				child.toInnerCoordinates(globalCoordinates);
			}
		}
		double newX;
		double newY;
		ShapeGroup Pgroup = this;
		double scaleX = (double)Pgroup.newEx.getWidth() / Pgroup.ex.getWidth();
		double scaleY = (double)Pgroup.newEx.getHeight() / Pgroup.ex.getHeight();
		double translateX = 0;
		double translateY = 0;
		while (Pgroup.parent != null) {
			Pgroup = Pgroup.parent;
			//scaleX *= (double)Pgroup.newEx.getWidth() / Pgroup.ex.getWidth();
			translateX += (double)(globalCoordinates.getX() + translateX - Pgroup.getExtent().getLeft()) / 
					((double)Pgroup.newEx.getWidth() / Pgroup.ex.getWidth()) + Pgroup.getOriginalExtent().getLeft() - globalCoordinates.getX() - translateX;
			//scaleY *= (double)Pgroup.newEx.getHeight() / Pgroup.ex.getHeight();
			translateY += (double)(globalCoordinates.getY() + translateY - Pgroup.getExtent().getTop()) / 
					((double)Pgroup.newEx.getHeight() / Pgroup.ex.getHeight()) + Pgroup.getOriginalExtent().getTop() - globalCoordinates.getY() - translateY;
		}
	
		if (Pgroup != this) {
			newX = (globalCoordinates.getX() - getExtent().getLeft() + translateX) / 
					scaleX + getOriginalExtent().getLeft();
			newY = ((globalCoordinates.getY() - getExtent().getTop()) + translateY) / 
					scaleY + getOriginalExtent().getTop();
		}

		else {
			newX = (double)(globalCoordinates.getX() - getExtent().getLeft()) / ((double)newEx.getWidth() / ex.getWidth()) + 
					getOriginalExtent().getLeft();
			newY = (double)(globalCoordinates.getY() - getExtent().getTop()) / ((double)newEx.getHeight() / ex.getHeight()) + 
					getOriginalExtent().getTop();
		}
		
		IntPoint innerCoordinates = new DoublePoint(newX, newY).round();
		return innerCoordinates;
	}
	
	
	/**
	 * Returns the coordinates in the globalcoordinate system of the point whose coordinates in this ShapeGroups innercoordinate's system are the given coordinates
	 * @return globalCoordinates
	 * @post Excecutes all the transformations of this ShapeGroup's and its ancestors's extent compared to their original extent
	 */
	public IntPoint toGlobalCoordinates(IntPoint innerCoordinates) {
		if (getSubgroups() != null) {
			for (ShapeGroup child: getSubgroups()) {
				child.toGlobalCoordinates(innerCoordinates);
			}
		}
		double newX;
		double newY;
		ShapeGroup Pgroup = this;
		double scaleX = (double)newEx.getWidth() / ex.getWidth();
		double scaleY = (double)newEx.getHeight() / ex.getHeight();
		double translateX = 0;
		double translateY = 0;
		while (Pgroup.parent != null) {
			Pgroup = Pgroup.parent;
			scaleX *= (double)Pgroup.newEx.getWidth() / Pgroup.ex.getWidth();
			translateX += (double)(getExtent().getLeft() + translateX - Pgroup.getOriginalExtent().getLeft()) * 
					((double)Pgroup.newEx.getWidth() / Pgroup.ex.getWidth()) + Pgroup.getExtent().getLeft() - getExtent().getLeft() - translateX;
			scaleY *= (double)Pgroup.newEx.getHeight() / Pgroup.ex.getHeight();
			translateY += (double)(getExtent().getTop() + translateY - Pgroup.getOriginalExtent().getTop()) * 
					((double)Pgroup.newEx.getHeight() / Pgroup.ex.getHeight()) + Pgroup.getExtent().getTop() - getExtent().getTop() - translateY;
		}
		
		if (Pgroup != this) {
			newX = (double)(innerCoordinates.getX() - getOriginalExtent().getLeft()) * 
					scaleX + translateX + getExtent().getLeft();
			newY = (double)(innerCoordinates.getY() - getOriginalExtent().getTop()) * 
					scaleY + translateY + getExtent().getTop();
		}
		
		else {
			newX = (double)(innerCoordinates.getX() - getOriginalExtent().getLeft()) * 
					((double)newEx.getWidth() / ex.getWidth()) + getExtent().getLeft();
			newY = (double)(innerCoordinates.getY() - getOriginalExtent().getTop()) * 
					((double)newEx.getHeight() / ex.getHeight()) + getExtent().getTop();
		}
	
		IntPoint globalCoordinates = new DoublePoint(newX, newY).round();
		return globalCoordinates;
	}
	
	
	/**
	 * Returns the coordinates in this ShapeGroup's innercoordinate system of the vector whose coordinates in the globalcoordinate system are the given coordinates
	 * @return innerCoordinates
	 * @post scales the IntVectors of all objects with the scaling of the extent and its ancestors
	 */
	public IntVector toInnerCoordinates(IntVector globalCoordinates) {
		if (getSubgroups() != null) {
			for (ShapeGroup child: getSubgroups()) {
				child.toInnerCoordinates(globalCoordinates);
			}
		}
		double widthChange = 1;
		double heightChange = 1;
		ShapeGroup Pgroup = this;
		 
		while (Pgroup.parent != null) {
			widthChange *= (double)Pgroup.newEx.getWidth()/Pgroup.ex.getWidth();
			heightChange *= (double)Pgroup.newEx.getHeight()/Pgroup.ex.getHeight();
			Pgroup = Pgroup.parent;
		}
		
		if (Pgroup != this) {
			widthChange *= (double)Pgroup.newEx.getWidth()/Pgroup.ex.getWidth();
			heightChange *= (double)Pgroup.newEx.getHeight()/Pgroup.ex.getHeight();
		}
		
		else {
			widthChange = (double)newEx.getWidth()/ex.getWidth();
			heightChange = (double)newEx.getHeight()/ex.getHeight();
		}
		
		IntVector innerCoordinates = new IntVector((int)(globalCoordinates.getX() / widthChange), 
				(int)(globalCoordinates.getY() / heightChange));
		return innerCoordinates;
	}
	
	
	/**
	 * Returns the first subgroup in this nonLeaf ShapeGroup's list of subgroups whose extent cointains the given point expressed in this ShapeGroup's innercoordinates system 
	 * @return child || null
	 * @post Returns the first child that contains the given point, else returns null
	 * 		//| getChildren().stream().firstMatch(child -> child.getExtent().contains(innerCoordinates)) || result == null
	 */
	public ShapeGroup getSubgroupAt(IntPoint innerCoordinates) {
		for (ShapeGroup child: getSubgroups()) {
			if (child.newEx.contains(innerCoordinates))
				return child;
		}
		return null;
	}
	
	
	/**
	 * Sets the given extent as this ShapeGroup's new extent and keeps its previous extent expressed in this ShapeGroups outercoordinate system
	 * @post the previous extent becomes the old new extent and the new extent equals the given extent
	 * 		| getExtent() == newExtent
	 * @throws IllegalArgumentException when the given extent is null
	 * 		| !(newExtent == null)
	 */
	public void setExtent(Extent newExtent) {
		if (newExtent == null)
			throw new IllegalArgumentException("Extent cannot be null!");
		else
			if (ex == null) { 
				ex = newExtent;
				prevEx = newExtent;
			}
			else
				prevEx = newEx;
			newEx = newExtent;
	}
	
	/**
	 * Moves this ShapeGroup to the front of its parent's list of subgroups
	 * @mutates_properties | getSubgroups()
	 * @post this ShapeGroup is the first element of its parent's children array 
	 * 		| this == getParentGroup().getSubgroup(0)
	 * @post the order of the other child ShapeGroups in the parent's children array is retained
	 * 		
	 */
	public void bringToFront() {
		if (this != parent.first) {
			if (next != null) {
				previous.next = next;
				next.previous = previous;
			}
			else {
				previous.next = null;
				parent.last = previous;
			}
			parent.first.previous = this;
			next = parent.first;
			previous = null;
			parent.first = this;
		}
	}
	
	
	/**
	 * Moves this ShapeGroup to the back of its parent's list of subgroups
	 * @mutates_properties | getSubgroups()
	 * @post this ShapeGroup is the last element of its parent's children array 
	 * 		| this == getParentGroup().getSubgroup(getSubgroupCount()-1)
	 * @post the order of the other child ShapeGroups in the parent's children array is retained
	 * 		
	 */
	public void sendToBack() {
		if (this != parent.last) {
			if (previous != null) {
				previous.next = next;
				next.previous = previous;
			}
			else {
				next.previous = null;
				parent.first = next;
			}
			parent.last.next = this;
			previous = parent.last;
			next = null;
			parent.last = this;
		}
	}

	
	/**
	 * Returns a textual representation of a sequence of drawing commands for drawing the shapes contained directly or indirectly
	 * by this ShapeGroup expressed in this ShapeGroups outercoordinate system
	 * @post contains all of the drawing commands for all leaf and nonLeaf ShapeGroups
	 */
	public java.lang.String getDrawingCommands(){
		

		String result = "";
		
		if (nonLeaf != null) {
		
			result += push(this);
			result += drawNonLeaf(this);
			result += "popTransform \r\n";
			result += "popTransform \r\n";
		}

		
		else if (leaf != null) {
			
			result += push(this);
			
			result += leaf.getDrawingCommands();
			
			result += "popTransform \r\n";
			result += "popTransform \r\n";
			
		}
		

		return result;
	}
	
	/**
	 * Specific drawing commands for nonLeaf ShapeGroups
	 * @post contains all drawing commands for all leaf ShapeGroups inside all nonLeaf ShapeGroups
	 */
	public java.lang.String drawNonLeaf(ShapeGroup subgroup) {
		String result = "";
		ShapeGroup child = subgroup.last;
		while (child != null) {
			if (child.leaf == null) {
				result += push(child);
				result += drawNonLeaf(child);
				result += "popTransform \r\n";
				result += "popTransform \r\n";
				
				
			}
			else {	
				result += push(child);
				result += child.leaf.getDrawingCommands();
				result += "popTransform \r\n";
				result += "popTransform \r\n";
			}
			child = child.previous;
		}
		return result;
	}
	
	
	/**
	 * Gives the drawing commands for translating and scaling the ShapeGroups
	 * @post all coordinates are scaled with a factor widthFactor and heightFactor and moved over a distance changeX and changeY 
	 */
	public java.lang.String push(ShapeGroup subgroup){
		String result = "";
		
		double widthFactor = (double)subgroup.getExtent().getWidth()/subgroup.getOriginalExtent().getWidth();
		double heightFactor = (double)subgroup.getExtent().getHeight()/subgroup.getOriginalExtent().getHeight();
		
		
		if (!subgroup.newEx.getTopLeft().equals(subgroup.prevEx.getTopLeft())) {
			double changeR = subgroup.getExtent().getRight() -subgroup.getOriginalExtent().getRight();
			double changeB = subgroup.getExtent().getBottom() - subgroup.getOriginalExtent().getBottom();
			subgroup.changeXr = (1-(widthFactor-changeR/subgroup.getOriginalExtent().getWidth()))*subgroup.getOriginalExtent().getRight();
			subgroup.changeYb = (1-(heightFactor-changeB/subgroup.getOriginalExtent().getHeight()))*subgroup.getOriginalExtent().getBottom();
		}
		
			
		else if (!subgroup.newEx.getBottomRight().equals(subgroup.prevEx.getBottomRight())) {
			double changeL = -subgroup.getExtent().getLeft() + subgroup.getOriginalExtent().getLeft();
			double changeT = -subgroup.getExtent().getTop() + subgroup.getOriginalExtent().getTop();
			subgroup.changeXl = (1-(widthFactor-changeL/subgroup.getOriginalExtent().getWidth()))*subgroup.getOriginalExtent().getLeft();
			subgroup.changeYt = (1-(heightFactor-changeT/subgroup.getOriginalExtent().getHeight()))*subgroup.getOriginalExtent().getTop();
		}
				
		double changeX = subgroup.changeXr + subgroup.changeXl;
		double changeY = subgroup.changeYb + subgroup.changeYt;
		
		
		result += "pushTranslate " + changeX + " " + changeY + "\r\n";
		result += "pushScale " + widthFactor + " " + heightFactor + "\r\n";
		
		return result;
	}
	
}